cpabe-java
==========

The implementation of Ciphertext Policy Attribute Based Encryption in Java.
