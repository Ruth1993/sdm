package cn.edu.pku.ss.crypto.abe;

import it.unisa.dia.gas.jpbc.Element;

import cn.edu.pku.ss.crypto.abe.serialize.Serializable;
import cn.edu.pku.ss.crypto.abe.serialize.SimpleSerializable;

public class PublicKey implements SimpleSerializable {
	@Serializable(group="G1")
	Element g; // G1 generator
	
	@Serializable(group="G2")
	Element gp; // G2 generator
	
	//e_hat = e(g,g)
	@Serializable(group="G2")
	Element e_hat; // G2 generator
	
	//y=e(g,g)^alpha
	@Serializable(group="GT")
	Element y; // GT
	
	//Tj = g^{tj} (1 <= j <= n)
	@Serializable(group="G1")
	Element[] T; //G1

}
